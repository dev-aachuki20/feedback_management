<footer class="main-footer">
<div class="pull-right hidden-xs">  </div>
<img  src="https://www.datagroupsolutions.com/wp-content/uploads/2020/11/Data-Group-Solutions-survey.png" alt="" width="148" height="27" /> <strong>Copyright &copy; <?php echo date('Y'); ?> </strong> Data Group Solutions All rights reserved. 
</footer>