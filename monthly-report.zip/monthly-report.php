<section class="content-header">
  <h1>Monthly Report</h1>
</section>
<section class="content">
  <div class="row">
  <div class="col-lg-12">
      <div class="box">
        <div class="box-body">
          <form action="" method="get">
          <input type="hidden" name="page" value="monthly-report" />
          <div class="col-md-8">
              <div class="form-group">
                <label>Select Survey</label>
                <select name="survey_name" class="form-control form-control-lg" required>
                <option value="">Select Survey</option>
                <?php 
                  record_set('getSurvey','select * from surveys');
                  if($totalRows_getSurvey>0){				
                  while($row_getSurvey = mysqli_fetch_assoc($getSurvey)){
                  ?>
                  <option <?php if($row_getSurvey['id']==$_GET['survey_name']){ ?> selected="selected" <?php } ?> value="<?php echo $row_getSurvey['id'];?>"><?php echo $row_getSurvey['name'];?></option>
                  <?php }}?>
                </select>
              </div>
            </div>
            <div class="col-md-8">
              <div class="form-group">
                <label>Location</label>
                <select name="locationid" id="locationid" class="form-control form-control-lg">
                <option value="">Select</option>
                <?php
                record_set("get_location", "select * from locations where cstatus=1 $locationDropDownCondition order by name asc");        
                while($row_get_location = mysqli_fetch_assoc($get_location)){ 
                ?>
                  <option value="<?php echo $row_get_location['id'];?>" <?php echo ($row_get_location['id'] == $_GET['locationid']) ? "selected" : "" ?>><?php echo $row_get_location['name'];?></option>
                <?php }?>
                </select>
              </div>
            </div>
            
           <div class="col-md-4">
              <div class="form-group">
                <label>&nbsp;</label>
                <input type="submit" name="filter" class="btn btn-primary btn-block" value="Filter"/>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <?php 
		record_set('getSurveyname','select * from surveys where id="'.$_REQUEST['survey_name'].'"');
		$row_getSurveyname = mysqli_fetch_assoc($getSurveyname);
		
	?>
    <div class="col-lg-12">
      <div class="box">
        <div class="box-header"><h3><?php echo $row_getSurveyname['name']?> monthly report</h3></div>
        <div class="box-body">        
          <table id="examples" class="table table-bordered table-striped">
            <thead>
              <tr >
                <td>Date Time</td>
                <td>Total Survey</td>               
                <td>Total Survey</td>               
                <td>Average Result Score</td>
                <td>Download PDF</td>
                <td>Download CSV</td>                
              </tr>
            </thead>
            <tbody>
            	<?php
        if(!empty($_REQUEST['filter'])){
          $filterQuery = "";
          if(isset($_REQUEST['survey_name']) && $_REQUEST['survey_name'] != '' && $_REQUEST['survey_name'] != 0){
            $filterQuery .= "where answers.surveyid=".$_REQUEST['survey_name'];
          }

          if(isset($_REQUEST['locationid']) && $_REQUEST['locationid'] != ''){
            if($_REQUEST['locationid'] == 4){
              if(!empty($filterQuery)){
                $filterQuery .= " and answers.locationid in (select id from locations where cstatus=1)";    
              }else{
                $filterQuery .= "where answers.locationid in (select id from locations where cstatus=1)"; 
              }
            }else{
              if(!empty($filterQuery)){  
                $filterQuery .= " and answers.locationid = '".$_REQUEST['locationid']."'";   
              }else{
                $filterQuery .= " where answers.locationid = '".$_REQUEST['locationid']."'";
              }
            }
          }else{
            $filterQuery .= $locationJoinCondition;
          }
					record_set("survey_detail","SELECT answers.surveyid,answers.locationid,surveys.name,answers.cdate FROM `answers` INNER JOIN surveys ON answers.surveyid=surveys.id $filterQuery group by YEAR(answers.cdate), MONTH(answers.cdate)");
					if($totalRows_survey_detail>0){
					while($row_survey_detail = mysqli_fetch_assoc($survey_detail)){
            $surveyFilter = '';
            if($_REQUEST['survey_name'] != 0){
              $surveyFilter = " and surveyid=".$_REQUEST['survey_name'];
            }
            if(isset($_REQUEST['locationid']) && $_REQUEST['locationid'] != '' && $_REQUEST['locationid'] != 4 ){
              $surveyFilter .= " and locationid=".$_REQUEST['locationid'];
            }
						record_set("survey_count","SELECT id from answers where cdate like '".date_month_qry($row_survey_detail['cdate'])."-%'  $surveyFilter group by cdate");
				    ?>
                <tr>
                 <td><?php echo date_formate_month($row_survey_detail['cdate']); ?></td>
                 <td><?php echo $totalRows_survey_count; ?></td>
                 <td><a class="btn btn-xs btn-info" href="survey-result.php?surveyid=<?php echo $row_survey_detail['surveyid'];?>&month=<?php echo date_month_qry($row_survey_detail['cdate']); ?>" target="_blank">View Result</a></td>
                 <?php 
                 //Average Result Score
                 record_set("average_survey_result","SELECT COUNT(answerval) AS survey_count, SUM(answerval) AS survey_val_sum FROM answers WHERE surveyid='".$row_survey_detail['surveyid']."' AND locationid='".$row_survey_detail['locationid']."' AND cdate like '".date_month_qry($row_survey_detail['cdate'])."-%' GROUP BY cby ORDER BY cdate DESC");
                 $achieved_result_val = 0;
                 $result_score = 0;
                 if($totalRows_average_survey_result > 0){
                  while($row_average_survey_result = mysqli_fetch_assoc($average_survey_result)){
                    $achieved_result_val += floatval($row_average_survey_result['survey_val_sum'] * 100) / floatval($row_average_survey_result['survey_count'] * 100);
                  }

                  $result_score = floatval($achieved_result_val) / intval($totalRows_average_survey_result);
                 }
                 ?>
                 <td><?php echo round($result_score,2); ?>%</td>
                 <td><a class="btn btn-xs bg-black" href="export-pdf.php?surveyid=<?php echo $row_survey_detail['surveyid'];?>&amp;month=<?php echo date_month_qry($row_survey_detail['cdate']); ?>&location=<?=$_GET['locationid']?>" target="_blank">Download PDF</a></td>
                 <td><a class="btn btn-xs bg-black" href="export-result.php?surveyid=<?php echo $row_survey_detail['surveyid'];?>&month=<?php echo date_month_qry($row_survey_detail['cdate']); ?>&location=<?=$_GET['locationid']?>&name=<?php echo $row_getSurveyname['name']?>" target="_blank">Download CSV</a></td>
                </tr>
              <?php }}
					}else{ ?>
              <tr><td colspan="5">No Record Found</td></tr>
              <?php  }?>
            </tbody>            
          </table>
        </div>
      </div>
    </div>
  </div>
</section>
