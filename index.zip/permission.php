<?php
$user_permission = array('add-department','manage-department','add-location','manage-locations','view-survey','view-statistics','add-user','view-user','manage-groups','add-group','import-user','add-user','monthly-report');

/* sidebar active permission */
$configuration = array('add-department','manage-department','add-location','manage-locations','add-group','manage-groups','view-survey');