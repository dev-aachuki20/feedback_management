    <!-- dashboard menu-->
    <li class="treeview profile-active">
        <a href="?page=add_admin&amp;id=1"><i class="fa fa-user"></i><span>Admin</span></a>
    </li>
    <li><a href="index.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
     <!-- Configuration menu-->
    <li class="treeview <?=make_sidebar_active($_GET['page'],$configuration )?>">
        <a href="#"><i class="fa fa-solid fa-gear"></i> <span>Configuration</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
            <li class="treeview <?=make_sidebar_active($_GET['page'],array('add-department','manage-department'))?>">
                <a href="#" class="nav-link "> <i class="fa fa-th-large"></i> <span>Departments</span> <i class="fa fa-angle-left pull-right"></i> </a> 
                <ul class="treeview-menu timeline-area child">
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'add-department')?>"><a href="?page=add-department" class="nav-link"> <i class=""></i> <span>Add Department</span></a> </li>
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'manage-department')?>"><a href="?page=manage-department" class="nav-link"> <i class=""></i> <span>View Departments</span></a> </li>
                </ul>
            </li>

            <li class="treeview <?=make_sidebar_active($_GET['page'],array('add-location','manage-locations'))?>">
                <a href="#" class="nav-link"> <i class="fa fa-map-marker-alt"></i> <span>Locations</span> <i class="fa fa-angle-left pull-right"></i></a> 
                <ul class="treeview-menu timeline-area child ">
                    <li class="treeview cusul-line  <?=make_sidebar_active($_GET['page'],'add-location')?>"><a href="?page=add-location" class="nav-link"> <i class=""></i> <span>Add Location</span></a> </li>
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'manage-locations')?>"><a href="?page=manage-locations" class="nav-link"> <i class=""></i> <span>View Locations</span></a> </li>
                </ul>
            </li>

            <li class="treeview <?=make_sidebar_active($_GET['page'],array('add-group','manage-groups'))?>">
                <a href="#" class="nav-link"> <i class="fa fa-layer-group"></i> <span>Groups</span> <i class="fa fa-angle-left pull-right"></i></a> 
                <ul class="treeview-menu timeline-area child">
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'add-group')?>"><a href="?page=add-group" class="nav-link"> <i class=""></i> <span>Add Group</span></a> </li>
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'manage-groups')?>"><a href="?page=manage-groups" class="nav-link"> <i class=""></i> <span>View Groups</span></a> </li>
                </ul>
            </li>

            <li class="treeview <?=make_sidebar_active($_GET['page'],array('view-survey'))?>">
                <a href="#" class="nav-link"> <i class="fa fa-list-alt"></i> <span>Surveys</span> <i class="fa fa-angle-left pull-right"></i></a> 
                <ul class="treeview-menu timeline-area child <?=make_sidebar_active($_GET['page'],'view-survey')?>">
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'view-survey')?> "><a href="?page=view-survey" class="nav-link"> <i class=""></i> <span>View Survey</span></a> </li>
                </ul>
            </li>
        </ul>
    </li>

     <!-- Surveys menu-->
    <li class="treeview <?=make_sidebar_active($_GET['page'],array('monthly-report','view-report','view-statistics','report-statistics'))?>">
        <a href="#"><i class="fa fa-poll"></i><span>  Surveys</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu ">
            <li class="treeview <?=make_sidebar_active($_GET['page'],array('monthly-report','view-report'))?>">
                <a href="#" class="nav-link "> <i class="fa fa-th-large"></i> <span>Responses</span> <i class="fa fa-angle-left pull-right"></i> </a> 
                <ul class="treeview-menu timeline-area child">
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'monthly-report')?>"><a href="?page=monthly-report" class="nav-link"> <i class=""></i> <span>Individual</span></a> </li>
                    <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'view-report')?>"><a href="?page=view-report" class="nav-link"> <i class=""></i> <span>Overall</span></a> </li>
                </ul>
            </li>
            <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'view-statistics')?>">
                <a href="?page=view-statistics" class="nav-link "> <i class="fa fa-pie-chart"></i> <span>Statistics</span> </a> 
            </li>
            <li class="treeview  cusul-line <?=make_sidebar_active($_GET['page'],'report-statistics')?>">
                <a href="?page=report-statistics" class="nav-link "> <i class="fa fa-bar-chart"></i> <span>Anaysis</span> </a> 
            </li>
        </ul>
    </li>

     <!-- Reports menu-->
    <li class="treeview ">
        <a href="#"><i class="fa fa-list-alt"></i> <span>Reports</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu timeline-area">
            <li class="treeview cusul-line">
                <a href="?page=#" class="nav-link"> <i class=""></i> <span>Create Report</span> </a> 
            </li>

            <li class="treeview cusul-line">
                <a href="?page=#" class="nav-link"> <i class=""></i> <span>View Templates</span> </a> 
            </li>

            <li class="treeview cusul-line">
                <a href="?page=#" class="nav-link"> <i class=""></i> <span>Schedule Report</span> </a> 
            </li>

            <li class="treeview cusul-line">
                <a href="?page=#" class="nav-link"> <i class=""></i> <span>View Schedule</span> </a> 
            </li>
        </ul>
    </li>

     <!-- Users menu-->
    <li class="treeview <?=make_sidebar_active($_GET['page'],array('add-user','import-user','view-user'))?>">
        <a href="#"><i class="fa fa-list-alt"></i> <span>Users</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu timeline-area">
            <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'add-user')?>">
                <a href="?page=add-user" class="nav-link"> <i class=""></i> <span>Add User</span> </a> 
            </li>

            <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'import-user')?>">
                <a href="?page=#" class="nav-link"> <i class=""></i> <span>Import Users</span> </a> 
            </li>

            <li class="treeview cusul-line <?=make_sidebar_active($_GET['page'],'view-user')?>">
                <a href="?page=view-user" class="nav-link"> <i class=""></i> <span>View Users</span> </a> 
            </li>
        </ul>
    </li>
    <li><a href="?page=logout"> <i class="fa fa-sign-out"></i> <span>Logout</span></a></li>