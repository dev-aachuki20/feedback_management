<style>
    .d-none{
        display: none !important;
    }
</style>
<section class="content-header">
  <h1>Report</h1>
</section>
<section class="content">
    <div class="row">
        <form action="" method="POST" id="viewReportcsv">
            <input type="hidden" name="post_values" value =<?=json_encode($_POST)?> >
            <div class="col-lg-12">
                <div class="box">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <input type="date" name="fdate" class="form-control" value="<?php //echo date('Y-m-d', strtotime('-1 months')); ?>"/>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <input type="date" name="sdate" class="form-control" value="<?php //echo date('Y-m-d'); ?>"/>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Survey</label>
                                    <select id="surveys" name="surveys" class="form-control">
                                        <option value="">Select</option>
                                        <?php
                                            record_set("get_surveys", "select * from surveys where cstatus=1  order by name asc"); 
                                            while($row_get_surveys = mysqli_fetch_assoc($get_surveys)){ 
                                        ?>
                                            <option value="<?php echo $row_get_surveys['id'];?>"><?php echo $row_get_surveys['name'];?></option>
                                        <?php }?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Location</label>
                                    <select name="locationid" id="locationid" class="form-control form-control-lg">
                                        <option value="">Select</option>
                                        <?php
                                            record_set("get_location", "select * from locations where cstatus=1 $locationDropDownCondition order by name asc");        
                                            while($row_get_location = mysqli_fetch_assoc($get_location)){ 
                                        ?>
                                            <option value="<?php echo $row_get_location['id'];?>"><?php echo $row_get_location['name'];?></option>
                                        <?php }?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Department</label>
                                    <select name="departmentid" id="departmentid" class="form-control form-control-lg">
                                        <option value="">Select</option>
                                        <?php
                                            record_set("get_department", "select * from departments where cstatus=1");        
                                            while($row_get_department = mysqli_fetch_assoc($get_department)){ 
                                        ?>
                                            <option value="<?php echo $row_get_department['id'];?>"><?php echo $row_get_department['name'];?></option>
                                        <?php }?>
                                    </select>
                                </div>
                            </div>
             
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <input type="submit" name="filter" class="btn btn-primary btn-block" value="Filter"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
               
                <button type="button" class="btn btn-success" id="exportascsv" style="margin-bottom: 20px;">Export CSV</button>
            </div>
        </form>
        <div class="col-lg-12" id="dataforpdf">
            <div class="box">
                <div class="box-header"></div>
                    <div class="box-body">
                        <table id="filterTable" class="table table-bordered table-striped" style="width:100%">
                            <thead>
                                <tr >
                                    <td>Date Time</td>
                                    <td>Survey</td>
                                    <!-- <td>Department</td> -->
                                    <td> Response</td>
                                    <td>Result Score</td>
                                    <td>Contacted?</td>
                                    <td class="notforpdf">Action</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    if(!empty($_POST['filter'])){
                                        $dateflag= false;
                                        $query = 'SELECT * FROM answers ';
                                        if(!empty($_POST['fdate']) && !empty($_POST['sdate'])){  
                                            $query .= " where cdate between '".date('Y-m-d', strtotime($_POST['fdate']))."' and '".date('Y-m-d', strtotime("+1 day",strtotime($_POST['sdate'])))."'";
                                            $dateflag= true;
                                        }

                                        if(!empty($_POST['departmentid'])){
                                            if($_POST['departmentid'] == 4){
                                                record_set("get_all_department","select id from departments where cstatus=1");	
                                                $all_departments = array();
                                                while($row_get_all_department = mysqli_fetch_assoc($get_all_department)){
                                                    $all_departments[] = $row_get_all_department['id'];
                                                }
                                                if($dateflag == true){
                                                    $query .= " and departmentid in (".implode(',',$all_departments).")";
                                                }else{
                                                    $query .= " where departmentid in (".implode(',',$all_departments).")";
                                                }  
                                            }else{
                                                if($dateflag == true){
                                                    $query .= " and departmentid = '".$_POST['departmentid']."'";
                                                }else{
                                                    $query .= " where departmentid = '".$_POST['departmentid']."' ";
                                                }
                                            }
                                        }

                                        if(!empty($_POST['locationid'])){
                                            if($_POST['locationid'] == 4){
                                                $query .= " and locationid in (select id from locations where cstatus=1)";  
                                            }else{
                                                if($dateflag == true){
                                                    $query .= "and locationid = '".$_POST['locationid']."'";
                                                }else{
                                                    $deptflag = (!empty($_POST['departmentid']))?'and':'where';
                                                    $query .= "".$deptflag." locationid = '".$_POST['locationid']."'";
                                                }
                                            }
                                        }
                                        // else{
                                        //     $query .= $locationQueryAndCondition;
                                        // }
                                        if(!empty($_POST['surveys'])){
                                            $query .= " where surveyid =".$_POST['surveys'];
                                            $dateflag= true;
                                        }

                                        $query .= " GROUP by cby order by cdate DESC";
                                        record_set("get_departments", "SELECT * FROM departments");	
                                        $departments = array();
                                        while($row_get_departments = mysqli_fetch_assoc($get_departments)){
                                            $departments[$row_get_departments['id']] = $row_get_departments['name'];
                                        }
                                        
                                        record_set("get_recent_entry",$query);	
                                        if($totalRows_get_recent_entry >0){
                                            $i=0;
                                            while($row_get_recent_entry = mysqli_fetch_assoc($get_recent_entry)){ $i++;
                                                record_set("get_survey_detail", "SELECT * FROM surveys where id='".$row_get_recent_entry['surveyid']."'");	
                                                $row_get_survey_detail = mysqli_fetch_assoc($get_survey_detail);
                                                $row_survey_entry = 1;
                                                record_set("survey_entry", "SELECT DISTINCT cby FROM answers where surveyid='".$row_get_survey_detail['id']."' and cby <".$row_get_recent_entry['cby']);
                                                $row_survey_entry = $totalRows_survey_entry+$row_survey_entry;
                                ?>
                                    <tr>
                                        <td><?php echo date("d-m-Y", strtotime($row_get_recent_entry['cdate'])); ?></td>
                                        <td><?php echo $row_get_survey_detail['name']; ?></td>
                                        <!-- <td><?php //echo $departments[$row_get_survey_detail['departmentid']]; ?></td> -->
                                        <td><?php echo ordinal($row_survey_entry); ?></td>
                                        <td>
                                            <?php
                                                $total_result_val=0;
                                                record_set("get_survey_result", "SELECT answerid,answerval,questionid,answertext FROM answers where surveyid='".$row_get_recent_entry['surveyid']."' and cby='".$row_get_recent_entry['cby']."'");
                                                $achieved_result_val = 0;
                                                $to_bo_contacted     = 0;
                                                $i=0;
                                                while($row_get_survey_result = mysqli_fetch_assoc($get_survey_result)){

                                                $result_question =  record_set_single("get_question_type", "SELECT answer_type FROM questions where id =".$row_get_survey_result['questionid']);
                                                    if($result_question){
                                                        if(!in_array($result_question['answer_type'],array(2,3,5))){
                                                            $total_result_val = ($i+1)*100;
                                                            $achieved_result_val += $row_get_survey_result['answerval'];
                                                            if($row_get_survey_result['answerid'] == -2 && $row_get_survey_result['answerval'] == 10){
                                                                $to_bo_contacted = 1;
                                                            }
                                                            $i++;
                                                        }
                                                    }
                                                    
                                                }
                                               
                                                $result_response = $achieved_result_val*100/$total_result_val;
                                                if($achieved_result_val==0 and $total_result_val==0){
                                                    $result_response=100;
                                                }
                                                $label_class = 'success';
                                                if($result_response<50){
                                                $label_class = 'danger';
                                                }else 
                                                if($result_response<75){
                                                $label_class = 'info';
                                                }
                                            ?>
                                            <label class="label label-<?php echo $label_class; ?>"><?php echo round($result_response,2); ?>%</label>
                                        </td>
                                        <td>
                                            <?php if($to_bo_contacted==1){ ?>
                                                <a class="btn btn-xs btn-success">Yes</a>
                                            <?php }else{ ?>
                                                <a class="btn btn-xs btn-info">No</a>
                                            <?php } ?>
                                        </td>
                                        <td class="notforpdf">
                                            <a class="btn btn-xs btn-success" href="survey-result.php?surveyid=<?php echo $row_get_recent_entry['surveyid'];?>&userid=<?php echo $row_get_recent_entry['cby'];?>" target="_blank">User Response</a> &nbsp; 
                                            <a class="btn btn-xs btn-info" href="survey-result.php?surveyid=<?php echo $row_get_recent_entry['surveyid'];?>" target="_blank">Survey Result</a>&nbsp; 
                                            
                                        </td>
                                    </tr>
                                <?php }}}else{ ?>
                                    <tr><td colspan="6">No Record Found</td></tr>
                                <?php  }?>
                            </tbody>
                            <tfoot class="notforpdf">
                                <tr>
                                    <td>Date Time</td>
                                    <td>Survey</td>
                                    <!--<td>Department</td>-->
                                    <td>Response</td>
                                    <td>Result Score</td>
                                    <td>Contacted?</td>
                                    <td>Action</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</section>
<script src='https://code.jquery.com/jquery-3.4.1.min.js'></script>
<!-- Resources -->

<script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.0.0-rc.7/dist/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jspdf-html2canvas@latest/dist/jspdf-html2canvas.min.js"></script> 
<script>
    $(document).on('click','#exportascsv',function(){
        $('#viewReportcsv').attr('action', 'export-report-table.php');
        $('#viewReportcsv').submit();
        $('#viewReportcsv').attr('action', '');
    })
    
</script>
