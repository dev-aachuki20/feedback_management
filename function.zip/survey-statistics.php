<style>
    .btn-outline-secondary {
        color: #6c757d;
        background-color: transparent;
        background-image: none;
        border-color: #6c757d;
        width: 100%;
    }
    .btn:focus {
        outline: none !important;
    }
</style>
<section class="content-header">
  <h1>Report</h1>
</section>
<section class="content">
    <div class="box">
        <div class="box-body">
            <div class="row">
                <div class="col-md-3">
                    <button type="button" class="btn btn-outline-secondary">Survey</button>
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn btn-outline-secondary">Group</button>
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn btn-outline-secondary">Location</button>
                </div>
                <div class="col-md-3">
                    <button type="button" class="btn btn-outline-secondary">Department</button>
                </div>
            </div>
            <div class="row filter_form">
                <form action="" method="POST" id="viewReportcsv">
                    <!-- <input type="hidden" name="post_values" value =<?=json_encode($_POST)?> > -->
                    <div class="box-header">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <h3 class="box-title"> Search</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <input type="date" name="fdate" class="form-control start_data" value="<?php //echo date('Y-m-d', strtotime('-1 months')); ?>"/>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <input type="date" name="sdate" class="form-control end_date" value="<?php //echo date('Y-m-d'); ?>"/>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label> Survey</label>
                                    <select name="survey_name" class="form-control form-control-lg surveys" required>
                                    <option value="">Select Survey</option>
                                    <?php 
                                    record_set('getSurvey','select * from surveys');
                                    if($totalRows_getSurvey>0){				
                                    while($row_getSurvey = mysqli_fetch_assoc($getSurvey)){
                                    ?>
                                    <option <?php if($row_getSurvey['id']==$_GET['survey_name']){ ?> selected="selected" <?php } ?> value="<?php echo $row_getSurvey['id'];?>"><?php echo $row_getSurvey['name'];?></option>
                                    <?php }}?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <input type="button" style="background-color: #00a65a !important;border-color: #008d4c;"name="filter" class="btn btn-success btn-block search" value="Search"/>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!-- <div3
                        <button type="button" class="btn btn-success" id="exportascsv" style="margin-bottom: 20px;">Export CSV</button>
                    </div> -->
                </form>
            </div>
        </div>
    </div>
</section>

