<?php 
include('function/function.php');
//Get Survey Details
$surveyid = $_GET['surveyid'];
$client_id = '';
if(isset($_GET['surveyid'])){
  record_set("get_survey", "select * from surveys where id='".$surveyid."' and cstatus=1");
  if($totalRows_get_survey > 0){
    $row_get_survey = mysqli_fetch_assoc($get_survey);
    $client_id = $row_get_survey['clientid'];
  }else{
    echo 'Wrong survey ID.'; 
    exit;
  }
}else{
  echo 'Missing survey ID.';  
  exit;
}

$co_action = "";
$contact_comment="";
$created_date ="";
$showAllComment =[];
if(isset($_GET['userid'])){
  
record_set("get_contact_action", "select * from survey_contact_action where user_id='".$_GET['userid']."'");
if($totalRows_get_contact_action > 0){ 
$i = 0;
  while($row_get_contact_action = mysqli_fetch_assoc($get_contact_action)){
    if($row_get_contact_action['action'] == 1){
      $showAllComment[$i]['action']='In progress';
    }
    if($row_get_contact_action['action'] == 2){
      $showAllComment[$i]['action']='Void';
    }
    if($row_get_contact_action['action'] == 3){
      $showAllComment[$i]['action']='Resolved';
    }
    
    $showAllComment[$i]['comment']=$row_get_contact_action['comment'];
    $showAllComment[$i]['created_date']=$row_get_contact_action['created_date'];
    $i++;
  }
}

record_set("get_contact_action_single", "select * from survey_contact_action where user_id='".$_GET['userid']."' order by action desc");
  if($totalRows_get_contact_action_single > 0){ 
    
    $row_get_contact_action_single = mysqli_fetch_assoc($get_contact_action_single);

    if($row_get_contact_action_single['action'] == 1){
      $co_action = "In progress";
      $contact_comment = $row_get_contact_action_single['comment'];
      $created_date=$row_get_contact_action_single['created_date'];

    }else if($row_get_contact_action_single['action'] == 2){
      $co_action =  "Void";
      $contact_comment = $row_get_contact_action_single['comment'];
      $created_date=$row_get_contact_action_single['created_date'];

    }else if($row_get_contact_action_single['action'] == 3){
      $co_action =  "Resolved";
      $contact_comment = $row_get_contact_action_single['comment'];
      $created_date=$row_get_contact_action_single['created_date'];

    }
  }
 
}

if(isset($_POST['contact_action']) && $_POST['contact_action'] != ""){

  $user_id = $_GET['userid'];
  record_set("total_contact", "select * from survey_contact_action where user_id=".$user_id." and action=".$_POST['contact_action']."");
 
  if($totalRows_total_contact > 0){
   
    $data_contact_action_update = array(
      "action"=> $_POST['contact_action'],
      "comment"=> $_POST['comment'],
      'created_date'=>date("Y-m-d H:i:s")
    );
    $whereCondition = 'user_id='.$user_id.' and action='.$_POST['contact_action'];
    $update_contact_action =  dbRowUpdate("survey_contact_action",$data_contact_action_update,$whereCondition);
    if($update_contact_action){
      header("Refresh:0");
    }

  }else{
    
    $data_contact_action = array(
      "user_id"=> $_GET['userid'],
      "action"=> $_POST['contact_action'],
      "comment"=> $_POST['comment'],
      'created_date'=>date("Y-m-d H:i:s")
    );
    $insert_contact_action =  dbRowInsert("survey_contact_action",$data_contact_action);
    if($insert_contact_action){
      header("Refresh:0");
    }
  }

}

//filter
$ans_filter_query='';
if($_REQUEST['userid']){
  $ans_filter_query .= " and cby='".$_REQUEST['userid']."' ";
}
if($_REQUEST['month']){
  $ans_filter_query .= " and cdate like '".$_REQUEST['month']."-%' ";
}

//Survey Steps 
$survey_steps = array();
if($row_get_survey['isStep'] == 1){
  record_set("get_surveys_steps", "select * from surveys_steps where survey_id='".$surveyid."' order by step_number asc");
  while($row_get_surveys_steps = mysqli_fetch_assoc($get_surveys_steps)){
    $survey_steps[$row_get_surveys_steps['id']]['number'] = $row_get_surveys_steps['step_number'];
    $survey_steps[$row_get_surveys_steps['id']]['title'] = $row_get_surveys_steps['step_title'];
  }
}

//Survey Questions
record_set("get_questions", "select * from questions where surveyid='".$surveyid."' and cstatus='1' and parendit='0' order by dposition asc");
$questions = array();
while($row_get_questions = mysqli_fetch_assoc($get_questions)){
  if($row_get_questions['survey_step_id'] != 0){
    $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['id'] = $row_get_questions['id'];
    $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['question'] = $row_get_questions['question'];
    $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['ifrequired'] = $row_get_questions['ifrequired'];
    $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['answer_type'] = $row_get_questions['answer_type'];
  }
}
?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $row_get_survey['name']; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <style>
  body {
        font-family: 'Roboto', sans-serif;
      }
.btn.btn-primary {
    color: white;
    background: navy;
    min-width: 100px;
}
      .depart-list {
        padding: 10px 0;
        list-style: none;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        max-width: 70%;
        margin: 0 auto;
      }

      .depart-list li {
        flex: 25%;
        max-width: 25%;
      }
        
      .depart-list h4 {
        margin: 0;
      }

      form#contactActionForm .form-group {
          display: flex;
          justify-content: center;
          padding-top:10px;
      }

      .form-control {
          display: block;
          width: 100%;
          height: calc(1.5em + .75rem + 2px);
          /* padding: .375rem .75rem; */
          font-size: 1rem;
          font-weight: 400;
          line-height: 1.5;
          color: #495057;
          background-color: #fff;
          background-clip: padding-box;
          border: 1px solid #ced4da;
          border-radius: .25rem;
          transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
      }

      .btn-primary {
          color: #fff;
          background-color: #007bff;
          border-color: #007bff;
      }
      .d-none{
        display:none !important;
      }
      .btn {
          display: inline-block;
          font-weight: 400;
          color: #212529;
          text-align: center;
          vertical-align: middle;
          padding: .375rem .75rem;
          font-size: 1rem;
          line-height: 1.5;
          border-radius: .25rem;
          transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
      }
      td {
      border: 1px solid gray;
      }
      table.table.table-bordered {
        border: 1px solid gray;
      }
      .col-md-6 {
        width: 48%;
        float: left;
        margin: 10px;
        text-align: left;
       
      }
      .col-md-3 {
        width: 48%;
        float: left;
        margin: 10px;
        text-align: left;
        
      }
      .col-md-8 {
        width: 80%;
        /* text-align: center; */
        margin-left: 10%;
        text-align: left;
        
      }
      .display-flex{
        display:flex;
      }
      table {
        text-align: left;
      }
    </style>
  </head>
  <body>
  <div id="reportPage">
    <div align="center"><img src="upload_image/logo.png" width="200"></div>
    
    <?php 
    record_set("get_loc_dep", "select locationid, departmentid from answers where surveyid='".$surveyid."' ".$ans_filter_query);
    $row_get_loc_dep = mysqli_fetch_assoc($get_loc_dep);
    
    //Department
    record_set("get_department", "select name from departments where id = '".$row_get_loc_dep['departmentid']."'");
    $row_get_department = mysqli_fetch_assoc($get_department);

    //Location
    record_set("get_location", "select name from locations where id = '".$row_get_loc_dep['locationid']."'");
    $row_get_location = mysqli_fetch_assoc($get_location);

     //School
     record_set("get_school", "select answertext from answers where surveyid ='".$surveyid."' and answerid='-3' and answerval='10' and cstatus=1");
    ?>
    
    <div class="row" style="text-align: center;" >
      <div class="col-md-12" style="width:80%;margin-left: 10%;">
        <?php //if(isset($_GET['contacted']) && $_GET['contacted'] == 1 && $co_action!='Resolved'){ ?>

          <div class="col-md-6 display-flex">
            <div class="col-md-3"><strong>Location :</strong></div>
            <div class="col-md-3"><strong><?php echo $row_get_location['name']; ?></strong></div>
            <!-- <ul class="depart-list">
                <li><h4>Location :</h4></li>
                <li><span><?php //echo $row_get_location['name']; ?></span></li>
            </ul> -->
          </div>
          <div class="col-md-6 display-flex">
            <div class="col-md-3"><strong>Department :</strong></div>
            <div class="col-md-3"><strong><?php echo $row_get_department['name']; ?></strong></div>
            <!-- <ul class="depart-list">
                <li><h4>Department :</h4></li>
                <li><span><?php //echo $row_get_department['name']; ?></span></li> 
            </ul> -->
          </div>
        <?php //} ?>
        
        <?php
        if($totalRows_get_school>0){
         $row_get_school = mysqli_fetch_assoc($get_school);
        ?>
          <ul class="depart-list">
            <li><h4>School :</h4></li>
            <li><span><?php echo $row_get_school['answertext']; ?></span></li> 
          </ul>
        <?php } ?>
      </div>
    </div>
    
     <div class="container" style="width:80%;margin-left: 10%;" align="center" >

          <h2 align="center" style="margin:0px;"> <?= $row_get_survey['name']; ?> </h2>
          <?php foreach($survey_steps AS $key => $value) {  ?>
            <h4 align="center" style="margin-top:20px;margin-bottom:10px;"><?php echo $value['number'].".".$value['title']; ?></h4>
            <table style="font-size:14px;width:100%;" border="1" align="center"  cellspacing="0" cellpadding="4" >
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Questions Choices</th>
                  <th scope="col">Answer</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $i=0;
              
                  foreach($questions[$key] AS $question){
                    $i++;
                    $questionid = $question['id']; 
                    $answer_type = $question['answer_type'];
                    $totalRows_get_child_questions = 0;
                    $questions_array = array();
                    $answers_array = array();
                  // for radio rating dropdown
                if($answer_type == 1 || $answer_type == 4 || $answer_type == 6){
                  record_set("get_questions_detail", "select * from questions_detail where questionid='".$questionid."' and surveyid='".$surveyid."' and cstatus='1'"); 
                  if($totalRows_get_questions_detail>0){
                    while($row_get_questions_detail = mysqli_fetch_assoc($get_questions_detail)){
                      if($row_get_questions_detail['condition_yes_no'] == 1){
                        $questions_array[$row_get_questions_detail['id']] = $row_get_questions_detail['description'].' (Conditional)';
                      }else{
                        $questions_array[$row_get_questions_detail['id']] = $row_get_questions_detail['description'];
                      }
                      
                    }
                  }
                  record_set("get_answers", "select * from answers where surveyid='".$surveyid."' ".$ans_filter_query." and questionid='".$questionid."' ");  
                  if($totalRows_get_answers>0){
                    while($row_get_answers = mysqli_fetch_assoc($get_answers)){
                      $answers_array[$row_get_answers['id']] = $row_get_answers['answerid'];
                    }
                  }
                  $question = $question['question'];
                  foreach($answers_array as $key => $value){
                    $answer_value =  $questions_array[$value];
                  }
                }
                // textbox or textarea
                if($answer_type == 2 || $answer_type == 3){
                  record_set("get_answers", "select * from answers where surveyid='".$surveyid."' ".$ans_filter_query." and questionid='".$questionid."' ");  
                    if($totalRows_get_answers>0){
                      while($row_get_answers = mysqli_fetch_assoc($get_answers)){
                      //print_r($row_get_answers);
                      if($row_get_answers['answerid']==0){
                        $answers_array[$row_get_answers['questionid']] = $row_get_answers['answertext'];
                      }else{
                        $answers_array[$row_get_answers['id']] = 0011;
                      }
                    
                    }
                  }
                  foreach($answers_array as $key => $value){
                    if($key == $question['id']){
                      $question = $question['question'];
                      $answer_value = $value;
                    }
                  }
                } 
                if($answer_type !=5){ ?>
                <tr>
                  <td scope="row"><?=$i?></td>
                  <td><?=$question?></td>
                  <td><?=$answer_value?></td>
                </tr>
                <?php } }?>
              </tbody>
            </table>
          <?php } foreach($showAllComment as $comm) { ?>
          
           <hr/>
            <div class="col-md-12">
                <div class="col-md-6 display-flex">
                    <div class="col-md-3"><strong>Status update to:</strong></div>
                    <div class="col-md-3"><?php echo $comm['action']; ?></div> 
                </div>
                <div class="col-md-6 display-flex">
                      <div class="col-md-3"><strong>USER NAME Contacted on:</strong></div>
                      <div class="col-md-3"><?php echo $comm['comment']; ?></div>
                </div>
                <div class="col-md-8 display-flex">
                  <div class="col-md-3"><strong>Comments</strong></div>
                  <div class="col-md-3"><?php echo $comm['created_date']; ?></div>
                </div>
            </div>
           <hr/>

          <?php } //if(isset($_GET['contacted']) && $_GET['contacted'] == 1 && $co_action!='Resolved'){ ?>
            <form id="contactActionForm" role="form" method="POST">
              <div class="row notforpdf" style="text-align: center;margin-top: 20px;">
                <div class="col-md-10">
                  <div class="col-md-6">
                    <label for="contact-date">CONTACT DATE</label>
                    <div class="form-group">
                      <input type="date" name="" id="" class="form-control">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <label for="contact-date">CONTACT STATUS</label>
                    <div class="form-group">
                      <select id="contact_action" name="contact_action" class="form-control" required="required">
                        <option value="">Select</option>
                        <option value="1" <?php echo ($co_action == 'In progress')?'selected':'';?>>In progress</option>
                        <option value="2" <?php echo ($co_action == 'Void')?'selected':'';?>>Void</option>
                        <option value="3" <?php echo ($co_action == 'Resolved')?'selected':'';?>>Resolved</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-8">
                    <label for="contact-date">CONTACT COMMENT</label>
                    <div class="form-group">
                        <textarea class="form-control" name="comment" placeholder="Comments" required="required"><?php echo (!empty($contact_comment))?$contact_comment:'';?></textarea>
                    </div>
                  </div>
                  <div class="col-md-8">
                    <div class="form-group">
                      <input type="submit" name="submit" value="Submit" class="btn btn-primary">
                    </div>
                  </div>
                </div>
              </div> 
            </form>
          <?php //} ?>
     </div>
    

    <div class="custom_contact_action" style="text-align: center;">
      <?php 
      if(!empty($co_action)){
        $client_name='';
        record_set("get_client", "select * from clients where id='".$client_id."' and cstatus=1");
        if($totalRows_get_client > 0){
          $row_get_client = mysqli_fetch_assoc($get_client);
            $client_name =  $row_get_client['name'];
        }
      ?>
      
        <?php
         foreach($showAllComment as $key=>$item){
          //  echo '<h3>'.ucfirst($client_name).' contacted on '.date("d/m/Y",strtotime($item['created_date'])).' | '.ucfirst($client_name).' '.$item['action'].' on '.date("d/m/Y",strtotime($item['created_date'])).' : comment : '.$item['comment'].'</h3>'; 
         }
        ?>
      <?php 
      }
      ?>
    </div>
    </div>
  </body>
<script src='https://code.jquery.com/jquery-3.4.1.min.js'></script>
<!-- Resources -->

<script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.0.0-rc.7/dist/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jspdf-html2canvas@latest/dist/jspdf-html2canvas.min.js"></script> 
<script>
    // start export pdf 
    const pages = document.getElementById('reportPage');
    $('#exportPDF').click(function(){
        $('.notforpdf').addClass('d-none');
        html2PDF(pages, {
            margin: [50,10],//PDF margin (in jsPDF units). Can be a single number, [vMargin, hMargin], or [top, left, bottom, right].
            jsPDF: {
                orientation: "p",
                unit: "in",
                format: 'letter',
            },
            html2canvas: { scale: 2 },
            imageType: 'image/jpeg',
            output: '.<?php echo $row_get_survey['name']; ?>/pdf/<?=date('Y-m-d-H-i-s')?>.pdf'
        });
        setTimeout(function(){
            window.location.reload();
        }, 2000);
    });

 // End export pdf
 </script>
</html>

