<?php 
include('function/function.php');
$surveyid=$_GET['surveyid'];
if(isset($_GET['surveyid'])){
	record_set("get_survey", "select * from surveys where id='".$surveyid."' and cstatus=1 ");	
	if($totalRows_get_survey>0){
		$row_get_survey = mysqli_fetch_assoc($get_survey);
	}else{
		echo 'Wrong survey ID.'; exit;
	}
}else{
	echo 'Missing survey ID.';  exit;
}

$ans_filter_query='';
if($_REQUEST['userid']){
	$ans_filter_query .= " and cby='".$_REQUEST['userid']."' ";
}
if($_REQUEST['month']){
	$ans_filter_query .= " and cdate like '".$_REQUEST['month']."-%' ";
}
if(!empty($_REQUEST['location']) && $_REQUEST['location']!=4){
	$ans_filter_query .= " and locationid = ".$_REQUEST['location'];
}
//Survey Steps 
$survey_steps = array();
if($row_get_survey['isStep'] == 1){
  record_set("get_surveys_steps", "select * from surveys_steps where survey_id='".$surveyid."' order by step_number asc");
  while($row_get_surveys_steps = mysqli_fetch_assoc($get_surveys_steps)){
    $survey_steps[$row_get_surveys_steps['id']]['number'] = $row_get_surveys_steps['step_number'];
    $survey_steps[$row_get_surveys_steps['id']]['title'] = $row_get_surveys_steps['step_title'];
  }
}

//Survey Questions
record_set("get_questions", "select * from questions where surveyid='".$surveyid."' and cstatus='1' and parendit='0' order by dposition asc");
$questions = array();
while($row_get_questions = mysqli_fetch_assoc($get_questions)){
  $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['id'] = $row_get_questions['id'];
  $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['question'] = $row_get_questions['question'];
  $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['ifrequired'] = $row_get_questions['ifrequired'];
  $questions[$row_get_questions['survey_step_id']][$row_get_questions['id']]['answer_type'] = $row_get_questions['answer_type'];
} 

record_set("get_loc_dep", "select locationid, departmentid from answers where surveyid='".$surveyid."' ".$ans_filter_query);
$row_get_loc_dep = mysqli_fetch_assoc($get_loc_dep);

//Department
record_set("get_department", "select name from departments where id = '".$row_get_loc_dep['departmentid']."'");
$row_get_department = mysqli_fetch_assoc($get_department);

//Location
record_set("get_location", "select name from locations where id = '".$row_get_loc_dep['locationid']."'");
$row_get_location = mysqli_fetch_assoc($get_location);
if(!empty($_GET['location']) and $_GET['location']!=4){
     $location_name =$row_get_location['name'];
}else{
     $location_name ="All";
}
$message = 
'<div align="center"><img src="upload_image/logo.png" width="200"></div>
<table width="100%">
  <thead>
    <tr>
      <td style="border-bottom:2px solid #000;"><h2 align="center" style="margin:0px;">
	    '.$row_get_survey['name'].' 
	</h2></td>
    </tr>
  </thead></table>
  <table width="100%">
	<tr>
		<td style="border-bottom:2px solid #000;">
			<span>Location :</span>
		</td>
		<td style="border-bottom:2px solid #000;">
			<span>'.$location_name.'</span>
		</td>
		<td style="border-bottom:2px solid #000;">
			<span>Department :</span>
		</td>
		<td style="border-bottom:2px solid #000;">
			<span>'.$row_get_department['name'].'</span>
		</td>
	</tr>
  </table>';

  foreach($survey_steps AS $key => $value) {
    $message .= '<h4 align="center" style="margin-top:20px;margin-bottom:10px;">'.$value['number'].'.'.$value['title'].'</h4>';

    foreach($questions[$key] AS $question){
      $questionid=$question['id'];
      $answer_type = $question['answer_type'];
      $totalRows_get_child_questions = 0;
      //1=radio	2=textbox	3=textarea	4=rating
      $questions_array = array();
      $answers_array = array();
      if($answer_type==1 || $answer_type==4 || $answer_type==6){
        //echo 'get_questions_detail';
        record_set("get_questions_detail", "select * from questions_detail where questionid='".$questionid."' and surveyid='".$surveyid."' and cstatus='1'");	
        if($totalRows_get_questions_detail>0){
          while($row_get_questions_detail = mysqli_fetch_assoc($get_questions_detail)){
            //print_r($row_get_questions_detail);
            $questions_array[$row_get_questions_detail['id']] = $row_get_questions_detail['description'];
          }
        }
        //print_r($questions_array);
        //echo 'get_answers';
        record_set("get_answers", "select * from answers where surveyid='".$surveyid."' ".$ans_filter_query." and questionid='".$questionid."'");	
        if($totalRows_get_answers>0){
          while($row_get_answers = mysqli_fetch_assoc($get_answers)){
            //print_r($row_get_answers);
            $answers_array[$row_get_answers['id']] = $row_get_answers['answerid'];
          }
        }
        //print_r($answers_array);
        $counts = array_count_values($answers_array);
        //echo $counts[84];
      }
      if($answer_type==2 || $answer_type==3){
        record_set("get_answers", "select * from answers where surveyid='".$surveyid."' ".$ans_filter_query." and questionid='".$questionid."' ");	
        if($totalRows_get_answers>0){
          while($row_get_answers = mysqli_fetch_assoc($get_answers)){
            //print_r($row_get_answers);
            $answers_array[$row_get_answers['id']] = $row_get_answers['answertext'];
          }
        }
        $counts = array_count_values($answers_array);
      }
      if($answer_type==1 || $answer_type==4 || $answer_type==6){
        if($answer_type==1){
          //get Child Questions
          $get_child_questions = "select * from questions where parendit='".$questionid."' and cstatus='1'";
          record_set("get_child_questions", $get_child_questions);
        }
        if(empty($totalRows_get_child_questions)){
            $message .='<table width="505px" align="center">
              <tr>
                <td align="center" colspan="2"><h3 style="margin-top:10px;">'.$question['question'].'</h3>
                </td>
              </tr>
              <tr>
                <td width="304px;">';
                  $clr_loop=0;
                  $table_display_data = array();
                  foreach($questions_array as $key=>$val){
                    $clr_loop++;
                    $total_ans = count($answers_array);
                    $percentage = (100/$total_ans)*$counts[$key];
                    $table_display_data[$val]['percantage']=$percentage;
                    $table_display_data[$val]['count']=$counts[$key];
                  } 
                  $message .= '
                </td>
              </tr>
              <tr>
                <td colspan="3">
                  <table style="font-size:14px;" border="1" width="100%" cellspacing="0" cellpadding="4">
                    <tr>
                      <td style="background-color:#f0f0f0;">Answer Choices</td>
                      <td style="background-color:#f0f0f0;">Result</td>
                      <td style="background-color:#f0f0f0;">Responses</td>
                    </tr>';
                    $total = 0;
                    foreach($table_display_data as $key=>$val){ 
                      $message .='<tr>
                        <td>'.$key.'</td>
                        <td>'.round($val['percantage'],2).'%</td>
                        <td>'.$val['count'].'</td>
                      </tr>';
                      $total +=$val['count'];
                    } 
                    $message .='<tr>
                    <td></td>
                    <td>Total</td>
                    <td>'.$total.'</td>
                  </tr>';
                  $message .='</table>
                </td>
              </tr>
              <tr>
                <td colspan="2" style="height:40px;">&nbsp;</td>
              </tr>
            </table>';
        } else{ 
        $message .= '<table width="505px" align="center">
          <tr>
            <td align="center" colspan="3">
              <h3 style="margin-top:10px;">'.$question['question'].'</h3>
            </td>
          </tr>
        </table>
        <table width="505px" align="center" style="font-size:14px;" border="1" cellspacing="0" cellpadding="4">
          <tbody>
            <tr>
              <td style="background-color:#f0f0f0;">&nbsp;</td>'.
              $child_answer = array();
              $tdloop = 0;
              record_set("get_questions_detail", "select * from questions_detail where questionid='".$questionid."' and surveyid='".$surveyid."' and cstatus='1'  ");
              while($row_get_questions_detail = mysqli_fetch_assoc($get_questions_detail)){ 
                $tdloop++; 
                $message .= '<td style="background-color:#f0f0f0;">'.
                  $child_answer[$row_get_questions_detail['id']]= $row_get_questions_detail['description'];
                  $row_get_questions_detail['description'];
                '</td>';
              }
            $message .= '</tr>';
            while($row_get_child_questions = mysqli_fetch_assoc($get_child_questions)){
              $message .= '<tr>
                <td style="background-color:#f0f0f0;">'.$row_get_child_questions['question'].'
                </td>';

                $answers_array = array();
                record_set("get_answers", "select * from answers where surveyid='".$surveyid."' ".$ans_filter_query." and questionid='".$row_get_child_questions['id']."' ");	
                if($totalRows_get_answers>0){
                  while($row_get_answers = mysqli_fetch_assoc($get_answers)){
                  //print_r($row_get_answers);
                  $answers_array[$row_get_answers['id']] = $row_get_answers['answerid'];
                  }
                }
                $anscount =  count($answers_array);
                $counts = array_count_values($answers_array);
              $message .= '</tr>';
            }
          $message .= '</tbody>
        </table>';
        }
      }
	  } 
  }
	
//$message .= '</table>';

//echo $message; exit;

// Include autoloader 
require_once 'dompdf/autoload.inc.php'; 
// Reference the Dompdf namespace 
use Dompdf\Dompdf; 
// Instantiate and use the dompdf class 
$dompdf = new Dompdf();
$dompdf->loadHtml($message); 
$dompdf->setPaper('A4', 'PORTRAIT'); 
// Render the HTML as PDF 
$dompdf->render(); 
/*// save pdf in folder
$pdf = $dompdf->output();
$file_location = "upload/trans_docs/".'Quotation'.$_GET['eid'].".pdf";
file_put_contents($file_location,$pdf);*/
// Output the generated PDF to Browser 
$dompdf->stream($_GET['name'], array("Attachment"=>0));
?>