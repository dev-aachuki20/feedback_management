<style>
    form {
  margin: 20px;
}
</style>

<input type="checkbox" onclick="toggle(this,'check')" />Check all?<br />

<input type="checkbox" class="check" />Bar 1<br />
<input type="checkbox" class="check" />Bar 2<br />
<input type="checkbox" class="check" />Bar 3<br />
<input type="checkbox" class="check" />Bar 4<br />


<script language="JavaScript">
function toggle(source,element) {
    var checkboxes = document.querySelectorAll('.'+ element);
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}
</script>